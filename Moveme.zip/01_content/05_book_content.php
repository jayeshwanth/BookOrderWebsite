<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Organic Chemistry Book content</title>
<link href="../05_scripts/byinquisition_en.css" rel="stylesheet" media="screen">
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 10px;
	margin-right: 0px;
	margin-bottom: 0px;
}
.style1 {color: #FFFF00}
-->
</style></head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td align="center" valign="top"><table width="860" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td align="center" valign="top"><table width="860" border="0" cellpadding="0" cellspacing="0" bgcolor="#000000">
              <tr>
                <td align="left" valign="top"><img src="../02_images/pictures/Inquisition_book_860x200px.jpg" alt="insquistion Press" width="860" height="200" /></td>
              </tr>
              <tr>
                <td align="left" valign="top"><table width="860" border="0" cellpadding="0" cellspacing="0" bgcolor="#333333">
                  <tr>
                    <td width="40"><img src="../02_images/pic_sys/one_pix.gif" width="40" height="20" /></td>
                    <td width="820"><a href="../index.php" target="_self">HOME</a>&nbsp;&nbsp;&nbsp;<span class="style1">|</span><a href="02_organic_model_kit.php" target="_self">&nbsp;&nbsp;&nbsp;organic model kit</a>&nbsp;&nbsp;&nbsp;<span class="style1">|</span><a href="03_bioorganic_model_kit.php" target="_self">&nbsp;&nbsp;&nbsp;bioorganic model kit</a>&nbsp;&nbsp;&nbsp;<span class="style1">|</span></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td align="left" valign="top"><table width="860" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="20" align="left" valign="top"><img src="../02_images/pic_sys/one_pix.gif" width="20" height="10" /></td>
                    <td width="200" align="left" valign="top"><img src="../02_images/pic_sys/one_pix.gif" width="200" height="10" /></td>
                    <td width="10" align="left" valign="top"><img src="../02_images/pic_sys/one_pix.gif" alt="" width="10" height="10" /></td>
                    <td width="610" align="left" valign="top"><img src="../02_images/pic_sys/one_pix.gif" width="610" height="10" /></td>
                    <td width="20" align="left" valign="top"><img src="../02_images/pic_sys/one_pix.gif" alt="" width="20" height="10" /></td>
                  </tr>
                  <tr>
                    <td width="20" align="left" valign="top">&nbsp;</td>
                    <td width="200" align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td align="left" valign="top"><img src="../02_images/pic_sys/one_pix.gif" alt="" width="25" height="15" /></td>
                        <td align="left" valign="top"><img src="../02_images/pic_sys/one_pix.gif" alt="" width="100" height="15" /></td>
                      </tr>
                      <tr>
                        <td width="25" align="left" valign="top"><img src="../02_images/pic_sys/one_pix.gif" alt="" width="25" height="25" /></td>
                        <td align="left" valign="top"><a href="04_book.php" target="_self">book</a> Description</td>
                      </tr>
                      <tr>
                        <td width="25" align="left" valign="top"><img src="../02_images/pic_sys/one_pix.gif" alt="" width="25" height="15" /></td>
                        <td align="left" valign="top"><a href="05_book_content.php" target="_self">-&gt; contents</a></td>
                      </tr>
                      <tr>
                        <td width="25" height="16" align="left" valign="top"><img src="../02_images/pic_sys/one_pix.gif" alt="" width="25" height="15" /></td>
                        <td align="left" valign="top"><a href="06_book_description.php" target="_self">-&gt; book description</a></td>
                      </tr>
                      <tr>
                        <td height="16" align="left" valign="top">&nbsp;</td>
                        <td align="left" valign="top"><a href="07_use_of_the_book.php" target="_self">-&gt; use of the book</a></td>
                      </tr>
                      <tr>
                        <td width="25" align="left" valign="top"><img src="../02_images/pic_sys/one_pix.gif" alt="" width="25" height="15" /></td>
                        <td align="left" valign="top"><a href="08_errata.php" target="_self">-&gt; errata</a></td>
                      </tr>
                      <tr>
                        <td align="left" valign="top"><img src="../02_images/pic_sys/one_pix.gif" alt="" width="25" height="15" /></td>
                        <td align="left" valign="top"><img src="../02_images/pic_sys/one_pix.gif" alt="" width="100" height="15" /></td>
                      </tr>
                      <tr>
                        <td align="left" valign="top">&nbsp;</td>
                        <td align="left" valign="top"><a href="09_about_the_author.php" target="_self">about the author</a></td>
                      </tr>
                      <tr>
                        <td align="left" valign="top">&nbsp;</td>
                        <td align="left" valign="top"><img src="../02_images/pic_sys/one_pix.gif" alt="" width="100" height="15" /></td>
                      </tr>
                      <tr>
                        <td align="left" valign="top">&nbsp;</td>
                        <td align="left" valign="top"><a href="http://shop.byinquisition.org/" target="_blank">place order here</a></td>
                      </tr>
                      <tr>
                        <td align="left" valign="top">&nbsp;</td>
                        <td align="left" valign="top">&nbsp;</td>
                      </tr>
                      <tr>
                        <td align="left" valign="top">&nbsp;</td>
                        <td align="left" valign="top">&nbsp;</td>
                      </tr>
                    </table></td>
                    <td width="10" align="left" valign="top" background="../02_images/pic_sys/dot_line_v150x10px_white.gif"><img src="../02_images/pic_sys/one_pix.gif" alt="" width="10" height="300" /></td>
                    <td width="610" align="left" valign="top">
                      <table width="610" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <td width="20" align="left" valign="top"><img src="../02_images/pic_sys/one_pix.gif" alt="" width="20" height="15" /></td>
                          <td width="590" align="left" valign="top"><img src="../02_images/pic_sys/one_pix.gif" alt="" width="590" height="15" /></td>
                        </tr>
                        <tr>
                          <td width="20" align="left" valign="top"><img src="../02_images/pic_sys/one_pix.gif" alt="" width="20" height="120" /></td>
                          <td width="590" align="left" valign="top">
                          <!-- content starts here -->
                          <table width="590" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                              <td width="30" height="25" align="left" valign="top">&nbsp;</td>
                              <td width="560" height="25" align="left" valign="top">&nbsp;</td>
                            </tr>
                            <tr>
                              <td width="30" height="25" align="left" valign="top"><span class="style1">A</span></td>
                              <td width="560" height="25" align="left" valign="top"><span class="style1">Acyclic Conformations</span></td>
                            </tr>
                            <tr>
                              <td width="30" height="25" align="left" valign="top"><span class="style1">B</span></td>
                              <td width="560" height="25" align="left" valign="top"><span class="style1">Cyclic Conformations</span></td>
                            </tr>
                            <tr>
                              <td width="30" height="25" align="left" valign="top"><span class="style1">C</span></td>
                              <td width="560" height="25" align="left" valign="top"><span class="style1">Nucleophilic Substitutions</span></td>
                            </tr>
                            <tr>
                              <td width="30" height="25" align="left" valign="top"><span class="style1">D</span></td>
                              <td width="560" height="25" align="left" valign="top"><span class="style1">Simple Hydrolysis Reactions</span></td>
                            </tr>
                            <tr>
                              <td width="30" height="25" align="left" valign="top"><span class="style1">E</span></td>
                              <td width="560" height="25" align="left" valign="top"><span class="style1">Elimination Reactions</span></td>
                            </tr>
                            <tr>
                              <td width="30" height="25" align="left" valign="top"><span class="style1">F</span></td>
                              <td width="560" height="25" align="left" valign="top"><span class="style1">Electrophilic Additions To Alkenes</span></td>
                            </tr>
                            <tr>
                              <td width="30" height="25" align="left" valign="top"><span class="style1">G</span></td>
                              <td width="560" height="25" align="left" valign="top"><span class="style1">Oxidation of Alcohols</span></td>
                            </tr>
                            <tr>
                              <td width="30" height="25" align="left" valign="top"><span class="style1">H</span></td>
                              <td width="560" height="25" align="left" valign="top"><span class="style1">Reduction of Carbonyl Groups</span></td>
                            </tr>
                            <tr>
                              <td width="30" height="25" align="left" valign="top"><span class="style1">I</span></td>
                              <td width="560" height="25" align="left" valign="top"><span class="style1">Nucleophilic Additions to Alkenes and Alkynes</span></td>
                            </tr>
                            <tr>
                              <td width="30" height="25" align="left" valign="top"><span class="style1">J</span></td>
                              <td width="560" height="25" align="left" valign="top"><span class="style1">Rearrangement Reactions</span></td>
                            </tr>
                            <tr>
                              <td width="30" height="25" align="left" valign="top"><span class="style1">K</span></td>
                              <td width="560" height="25" align="left" valign="top"><span class="style1">Orbital Controlled Reactions</span></td>
                            </tr>
                            <tr>
                              <td width="30" height="25" align="left" valign="top"><span class="style1">L</span></td>
                              <td width="560" height="25" align="left" valign="top"><span class="style1">Alkylation of Enolates</span></td>
                            </tr>
                            <tr>
                              <td width="30" height="25" align="left" valign="top"><span class="style1">M</span></td>
                              <td width="560" height="25" align="left" valign="top"><span class="style1">Reactions of Enolates with Carbonyl Compounds</span></td>
                            </tr>
                            <tr>
                              <td width="30" height="25" align="left" valign="top"><span class="style1">N</span></td>
                              <td width="560" height="25" align="left" valign="top"><span class="style1">Organoboron Reagents</span></td>
                            </tr>
                            <tr>
                              <td height="25" align="left" valign="top"><span class="style1">O</span></td>
                              <td height="25" align="left" valign="top"><span class="style1">Alkene and Alkyne Syntheses</span></td>
                            </tr>
                            <tr>
                              <td height="25" align="left" valign="top"><span class="style1">P</span></td>
                              <td height="25" align="left" valign="top"><span class="style1">Organosulfur Reagents</span></td>
                            </tr>
                            <tr>
                              <td height="25" align="left" valign="top"><span class="style1">Q</span></td>
                              <td height="25" align="left" valign="top"><span class="style1">Nucleophilic Metal Reagents</span></td>
                            </tr>
                            <tr>
                              <td align="left" valign="top">&nbsp;</td>
                              <td align="left" valign="top">&nbsp;</td>
                            </tr>
                          </table>
               
                    <!-- end of content -->                          </td>
                        </tr>
                        <tr>
                          <td width="20" align="left" valign="top">&nbsp;</td>
                          <td width="590" align="left" valign="top">&nbsp;</td>
                        </tr>
                        <tr>
                          <td width="20" align="left" valign="top">&nbsp;</td>
                          <td width="590" align="left" valign="top">&nbsp;</td>
                        </tr>
                      </table>                    </td>
                    <td width="20">&nbsp;</td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td align="left" valign="top"><img src="../02_images/pic_sys/one_pix.gif" width="860" height="15" /></td>
              </tr>
              <tr>
                <td align="left" valign="top"><table width="860" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td align="left" valign="top"><img src="../02_images/pictures/schwarz_line_860px.jpg" width="860" height="20" /></td>
                  </tr>
                  <tr>
                    <td align="left" valign="top"><table width="860" border="0" cellpadding="0" cellspacing="0" bgcolor="#333333">
                      <tr>
                        <td width="40" align="left" valign="top"><img src="../02_images/pic_sys/one_pix.gif" alt="" width="40" height="20" /></td>
                        <td align="left" valign="top">
                        
                        <div class="sf_footer">
			<!-- Footer:Begin -->
			<div class="style7" style="display:block;" >Content copyright <script type='text/javascript'>if (typeof(getCopyrightDate)=='function') document.write(getCopyrightDate(2010, null, '-')); else document.write((new Date()).getFullYear());</script>. By Inquisition Press. All rights reserved.</div>			
			<!-- Footer:Begin -->
		</div><!-- /sf_footer -->
                        
                        
                        </td>
                      </tr>
                    </table></td>
                  </tr>
                </table></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
