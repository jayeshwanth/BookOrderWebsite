<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Inquisition Press</title>
<link href="05_scripts/byinquisition_en.css" rel="stylesheet" media="screen">
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 10px;
	margin-right: 0px;
	margin-bottom: 0px;
}
.style1 {color: #FFFF00}
.style2 {color: #FF3300}
-->
</style></head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td align="center" valign="top"><table width="860" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td align="center" valign="top"><table width="860" border="0" cellpadding="0" cellspacing="0" bgcolor="#000000">
              <tr>
                <td align="left" valign="top"><img src="02_images/pictures/organic_head_860x200px.jpg" alt="insquistion Press" width="860" height="200" /></td>
              </tr>
              <tr>
                <td align="left" valign="top"><table width="860" border="0" cellpadding="0" cellspacing="0" bgcolor="#333333">
                  <tr>
                    <td width="40"><img src="02_images/pic_sys/one_pix.gif" width="40" height="20" /></td>
                    <td width="820"><a href="index.php" target="_self">HOME</a>&nbsp;&nbsp;&nbsp;<span class="style1">|</span><a href="01_content/02_organic_model_kit.php" target="_self">&nbsp;&nbsp;&nbsp;organic model kit</a>&nbsp;&nbsp;&nbsp;<span class="style1">|</span><a href="01_content/03_bioorganic_model_kit.php" target="_self">&nbsp;&nbsp;&nbsp;bioorganic model kit</a>&nbsp;&nbsp;&nbsp;<span class="style1">|</span></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td align="left" valign="top"><table width="860" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="20" align="left" valign="top"><img src="02_images/pic_sys/one_pix.gif" width="20" height="10" /></td>
                    <td width="200" align="left" valign="top"><img src="02_images/pic_sys/one_pix.gif" width="200" height="10" /></td>
                    <td width="10" align="left" valign="top"><img src="02_images/pic_sys/one_pix.gif" alt="" width="10" height="10" /></td>
                    <td width="610" align="left" valign="top"><img src="02_images/pic_sys/one_pix.gif" width="610" height="10" /></td>
                    <td width="20" align="left" valign="top"><img src="02_images/pic_sys/one_pix.gif" alt="" width="20" height="10" /></td>
                  </tr>
                  <tr>
                    <td width="20" align="left" valign="top">&nbsp;</td>
                    <td width="200" align="left" valign="top">
                    
                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr>
                                  <td align="left" valign="top"><img src="02_images/pic_sys/one_pix.gif" alt="" width="25" height="15"></td>
                                  <td align="left" valign="top"><img src="02_images/pic_sys/one_pix.gif" alt="" width="100" height="15"></td>
                                </tr>
                                <tr>
                                  <td width="25" align="left" valign="top"><img src="02_images/pic_sys/one_pix.gif" alt="" width="25" height="25"></td>
                                  <td align="left" valign="top"><a href="01_content/04_book.php" target="_self">book</a> Description</td>
                                </tr>
                                <tr>
                                  <td width="25" align="left" valign="top"><img src="02_images/pic_sys/one_pix.gif" alt="" width="25" height="15"></td>
                                  <td align="left" valign="top"><a href="01_content/05_book_content.php" target="_self">-&gt; contents</a></td>
                                </tr>
                                <tr>
                                  <td width="25" height="16" align="left" valign="top"><img src="02_images/pic_sys/one_pix.gif" alt="" width="25" height="15"></td>
                                  <td align="left" valign="top"><a href="01_content/06_book_description.php" target="_self">-&gt; book description</a></td>
                                </tr>
                                <tr>
                                  <td height="16" align="left" valign="top">&nbsp;</td>
                                  <td align="left" valign="top"><a href="01_content/07_use_of_the_book.php" target="_self">-&gt; use of the book</a></td>
                                </tr>
                                <tr>
                                  <td width="25" align="left" valign="top"><img src="02_images/pic_sys/one_pix.gif" alt="" width="25" height="15"></td>
                                  <td align="left" valign="top"><a href="01_content/08_errata.php" target="_self">-&gt; errata</a></td>
                                </tr>
                                <tr>
                                  <td align="left" valign="top"><img src="02_images/pic_sys/one_pix.gif" alt="" width="25" height="15"></td>
                                  <td align="left" valign="top"><img src="02_images/pic_sys/one_pix.gif" alt="" width="100" height="15" /></td>
                                </tr>
                                <tr>
                                  <td align="left" valign="top">&nbsp;</td>
                                  <td align="left" valign="top"><a href="01_content/09_about_the_author.php" target="_self">about the author</a></td>
                                </tr>
                                <tr>
                                  <td align="left" valign="top">&nbsp;</td>
                                  <td align="left" valign="top"><img src="02_images/pic_sys/one_pix.gif" alt="" width="100" height="15" /></td>
                                </tr>
                                <tr>
                                  <td align="left" valign="top">&nbsp;</td>
                                  <td align="left" valign="top"><a href="http://shop.byinquisition.org/" target="_blank">place order here</a></td>
                                </tr>
                                <tr>
                                  <td align="left" valign="top">&nbsp;</td>
                                  <td align="left" valign="top">&nbsp;</td>
                                </tr>
                                <tr>
                                  <td align="left" valign="top">&nbsp;</td>
                                  <td align="left" valign="top">&nbsp;</td>
                                </tr>
                            </table>                    </td>
                    <td width="10" align="left" valign="top" background="02_images/pic_sys/dot_line_v150x10px_white.gif"><img src="02_images/pic_sys/one_pix.gif" alt="" width="10" height="300" /></td>
                    <td width="610" align="left" valign="top">
                  
                    <table width="610" border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td width="20" align="left" valign="top"><img src="02_images/pic_sys/one_pix.gif" width="20" height="10" /></td>
                        <td align="left" valign="top"><img src="02_images/pic_sys/one_pix.gif" width="590" height="10" /></td>
                      </tr>
                      <tr>
                        <td align="left" valign="top">&nbsp;</td>
                        <td align="left" valign="top">  <!-- content starts here -->
                        <span class="menuHead style2">
                    By Inquisition Press</span><span class="style1"><br />
                    <br>
                    available at this site<br />
                    <br />
                    <br>
                    <br />
                    <img src="02_images/pictures/buecher.jpg" alt="Organic Chemistry" width="359" height="287" /><br><br><br>
&ldquo;Organic Chemistry By Inquisition&rdquo;<br />
<br>
a book of questions and answers covering many reactions <br />
used in contemporary organic chemistry<br>
molecular models recommended by the author <br />
to complement the book:<br />
<br>
5000 bioorganic set, and <br />
4010 organic set</span><br />
<br />
                   <!-- end of content -->    
                        
                        
                        </td>
                      </tr>
                    </table>
                    
               
                    
                 </td>
                    <td width="20">&nbsp;</td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td align="left" valign="top"><img src="02_images/pic_sys/one_pix.gif" width="860" height="15" /></td>
              </tr>
              <tr>
                <td align="left" valign="top"><table width="860" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td align="left" valign="top"><img src="02_images/pictures/schwarz_line_860px.jpg" width="860" height="20" /></td>
                  </tr>
                  <tr>
                    <td align="left" valign="top"><table width="860" border="0" cellpadding="0" cellspacing="0" bgcolor="#333333">
                      <tr>
                        <td width="40" align="left" valign="top"><img src="02_images/pic_sys/one_pix.gif" alt="" width="40" height="20" /></td>
                        <td align="left" valign="top">
                        
                        <div class="sf_footer">
			<!-- Footer:Begin -->
			<div class="style7" style="display:block;" >Content copyright <script type='text/javascript'>if (typeof(getCopyrightDate)=='function') document.write(getCopyrightDate(2010, null, '-')); else document.write((new Date()).getFullYear());</script>. By Inquisition Press. All rights reserved.</div>			
			<!-- Footer:Begin -->
		</div><!-- /sf_footer -->
                        
                        
                        </td>
                      </tr>
                    </table></td>
                  </tr>
                </table></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
