<?php
//Datenbank connecting
$conn =mysql_connect($dbhost, $dbuser, $password);
$db =mysql_select_db('classicproject_com_db');

?>