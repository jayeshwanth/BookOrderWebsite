<?php
//Datenbankzugang
$dbhost ="localhost";
$dbuser ="";
$password ="";

//$dbhost ="localhost";
//$dbuser ="classicproject";
//$password ="oooppp";

?>